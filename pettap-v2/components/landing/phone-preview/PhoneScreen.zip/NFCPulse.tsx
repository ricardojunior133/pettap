"use client";

import { motion, MotionValue } from "framer-motion";

interface Props {
  opacity: MotionValue<number>;
}

export default function NFCPulse({
  opacity,
}: Props) {
  return (
    <motion.div
      style={{ opacity }}
      className="
      absolute
      left-[34%]
      top-1/2
      z-20
      -translate-y-1/2
      pointer-events-none
      "
    >
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="absolute rounded-full border-2 border-sky-400/60"
         animate={{
    scale: [0.2, 2.2],
    opacity: [0.55, 0],
}}
          transition={{
            duration: 1.8,
            repeat: Infinity,
            delay: i * 0.35,
            ease: "easeOut",
          }}
        />
      ))}
    </motion.div>
  );
}