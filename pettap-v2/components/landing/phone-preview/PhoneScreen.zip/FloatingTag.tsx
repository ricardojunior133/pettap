"use client";

import Image from "next/image";
import { motion, MotionValue } from "framer-motion";

interface FloatingTagProps {
  x: MotionValue<number>;
  y: MotionValue<number>;
  rotate: MotionValue<number>;
  scale: MotionValue<number>;
}

export default function FloatingTag({
  x,
  y,
  rotate,
  scale,
}: FloatingTagProps) {
  return (
    <motion.div
    animate={{
        y: [0, -6, 0],
    }}
    transition={{
        duration: 3,
        repeat: Infinity,
        ease: "easeInOut",
    }}
    style={{
        x,
        y,
        rotate,
        scale,
    }}
>
      className="absolute left-[8%] top-1/2 z-30 -translate-y-1/2 hidden lg:block"
    
      <Image
        src="/images/tag/black.png"
        alt="PetTap Tag"
        width={180}
        height={180}
        priority
      />
    </motion.div>
  );
}