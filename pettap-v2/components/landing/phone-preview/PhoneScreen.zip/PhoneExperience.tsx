"use client";

import { useRef } from "react";
import {
  motion,
  useScroll,
  useTransform,
} from "framer-motion";

import FloatingTag from "./FloatingTag";
import NFCPulse from "./NFCPulse";
import IphoneMockup from "./IphoneMockup";
import PhoneScreen from "./PhoneScreen";

import { PHONE_TIMELINE } from "./timeline";

export default function PhoneExperience() {
  const ref = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  /*
  -----------------------------------
  TAG
  -----------------------------------
  */

  const tagX = useTransform(
  scrollYProgress,
  [0, 0.08, 0.18],
  [-320, 60, 260]
);

const tagY = useTransform(
  scrollYProgress,
  [0, 0.08, 0.18],
  [-180, -120, -30]
);

const tagRotate = useTransform(
  scrollYProgress,
  [0, 0.08, 0.18],
  [-32, -18, -6]
);

const tagScale = useTransform(
  scrollYProgress,
  [0, 0.08, 0.18],
  [0.7, 0.9, 1]
);

  /*
  -----------------------------------
  NFC
  -----------------------------------
  */

  const pulseOpacity = useTransform(
    scrollYProgress,
    [
      PHONE_TIMELINE.NFC.START,
      PHONE_TIMELINE.NFC.END,
    ],
    [0, 1]
  );

  /*
  -----------------------------------
  PHONE
  -----------------------------------
  */

  const phoneScale = useTransform(
  scrollYProgress,
  [0.12, 0.25, 0.40],
  [0.92, 0.97, 1]
);

const phoneY = useTransform(
  scrollYProgress,
  [0.12, 0.25, 0.40],
  [90, 25, 0]
);


  return (
    <section
      ref={ref}
      className="relative h-[350vh]"
    >
      <div className="sticky top-0 flex h-screen items-center justify-center overflow-hidden">
<div className="absolute inset-0">
  <div className="absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-sky-400/10 blur-[120px]" />
</div>
        {/* Floating Tag */}

        <FloatingTag
          x={tagX}
          y={tagY}
          rotate={tagRotate}
          scale={tagScale}
        />

        {/* NFC */}

        <NFCPulse
          opacity={pulseOpacity}
        />

        {/* Phone */}

       <motion.div
  style={{
    y: phoneY,
    scale: phoneScale,
  }}
>
          <IphoneMockup>
            <PhoneScreen
              progress={scrollYProgress}
            />
          </IphoneMockup>
        </motion.div>

      </div>
    </section>
  );
}