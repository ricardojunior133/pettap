"use client";

import { MotionValue, motion, useTransform } from "framer-motion";

import SplashScreen from "./screens/SplashScreen";
import PetProfile from "./screens/PetProfile";
import SuccessScreen from "./screens/SuccessScreen";

interface PhoneScreenProps {
  progress: MotionValue<number>;
}

export default function PhoneScreen({
  progress,
}: PhoneScreenProps) {
  /*
   * SPLASH
   */

  const splashOpacity = useTransform(
    progress,
    [0.30, 0.40, 0.50],
    [1, 1, 0]
  );

  /*
   * PROFILE
   */

  const profileOpacity = useTransform(
    progress,
    [0.45, 0.60, 0.85],
    [0, 1, 1]
  );

  const profileY = useTransform(
    progress,
    [0.45, 0.60],
    [30, 0]
  );

  /*
   * SUCCESS
   */

  const successOpacity = useTransform(
    progress,
    [0.90, 1],
    [0, 1]
  );

  return (
    <div className="relative h-full w-full overflow-hidden">

      {/* Splash */}

      <motion.div
        style={{
          opacity: splashOpacity,
        }}
        className="absolute inset-0"
      >
        <SplashScreen />
      </motion.div>

      {/* Profile */}

      <motion.div
        style={{
          opacity: profileOpacity,
          y: profileY,
        }}
        className="absolute inset-0"
      >
        <PetProfile />
      </motion.div>

      {/* Success */}

      <motion.div
        style={{
          opacity: successOpacity,
        }}
        className="absolute inset-0"
      >
        <SuccessScreen />
      </motion.div>

    </div>
  );
}